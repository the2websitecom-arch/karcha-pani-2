# Kharcha

A monthly expense tracker for your phone and laptop. Sign in with email or Google, keep your data in your own Firebase project, and let payment messages add themselves.

- Monthly summary with budget meter, category chart and day-by-day chart
- Email and Google sign-in, data synced across devices (works offline, syncs when back online)
- Paste a bank or UPI message and Kharcha reads the amount, shop and date
- Automatic capture: your phone forwards payment messages to your own endpoint
- Installs on a phone home screen like an app

Without Firebase keys the app runs in **demo mode**: no sign-in, example data, saved only in that browser.

## What "automatic" can and cannot do

A website cannot read your SMS or notifications. Browsers do not allow it on any phone. Automatic capture therefore works like this:

1. A free automation app on your phone (MacroDroid or Tasker on Android, Shortcuts on iPhone) notices a payment message.
2. It sends the message text to a small Firebase function that you deploy.
3. The function reads the amount and shop and adds the expense to your account.
4. Your Kharcha screen updates within a few seconds.

OTPs, failed payments and money you received are ignored. Sending the same message twice adds it once. Shops are matched to categories by name (Swiggy is Food, BigBasket is Groceries, and so on). Anything unknown lands in Shopping, and you can delete and re-add it with the right category.

A fully hands-free option with no helper app needs a native Android app that holds the SMS permission. That is a separate project.

## Files

| File | What it is |
| --- | --- |
| `index.html`, `css/style.css` | The page and its styles |
| `js/app.js` | Screens and interactions |
| `js/store.js` | Data layer: Firebase (signed in) or browser storage (demo) |
| `js/parser.js` | Reads payment messages |
| `js/firebase-config.js` | **Where you paste your Firebase keys** |
| `functions/` | Cloud function that receives forwarded messages |
| `firestore.rules` | Who can read and write what |
| `manifest.webmanifest`, `sw.js`, `icons/` | Makes the app installable and lets Android share messages to it |

`functions/parser.js` is a copy of `js/parser.js`. If you change one, copy it to the other.

## Set up

### 1. Create the Firebase project

1. Go to <https://console.firebase.google.com> and create a project.
2. Build, Authentication, Get started. Turn on **Email/Password** and **Google**.
3. Build, Firestore Database, Create database. Pick a region near you (Mumbai, `asia-south1`) and start in production mode.
4. Project settings, General, Your apps, add a **Web app**. Copy the config object.
5. Paste those values into `js/firebase-config.js`.

### 2. Publish the rules

Install the Firebase CLI once: `npm install -g firebase-tools`, then `firebase login`.

In this folder:

```
firebase use --add          # choose your project
firebase deploy --only firestore:rules
```

You can also paste `firestore.rules` into Firestore Database, Rules, in the console.

### 3. Put the site on GitHub Pages

1. Push this folder to a GitHub repository.
2. Settings, Pages, Deploy from a branch, `main` and `/ (root)`.
3. Your site is at `https://<username>.github.io/<repository>/`.
4. In Firebase, Authentication, Settings, **Authorized domains**, add `<username>.github.io`. Sign-in fails without this step.

The app uses ES modules, so opening `index.html` straight from your disk does not work. To test locally run `python3 -m http.server 8000` in this folder and open <http://localhost:8000>. `localhost` is already an authorized domain.

### 4. Turn on automatic capture

Cloud Functions need the Firebase **Blaze** plan (pay as you go). A personal expense tracker stays inside the free monthly allowance, but Google asks for a card to enable it.

```
cd functions
npm install
cd ..
firebase deploy --only functions
```

The command prints the address of the `ingest` function. Paste it into `ingestUrl` in `js/firebase-config.js` and push again.

Then in the app, open **Automatic capture**. It shows your endpoint address and your private key.

**Android (MacroDroid or Tasker)**

1. Trigger: SMS received, with the message containing "debited", "spent" or "paid". For GPay or PhonePe use the notification-received trigger.
2. Action: HTTP request, method POST, content type JSON.
3. Body: `{"key":"YOUR KEY","text":"MESSAGE TEXT"}`, where MESSAGE TEXT is the variable the app provides for the message body.

**iPhone (Shortcuts)**

1. Automation, Message, message contains "debited" or "spent".
2. Action: Get contents of URL, POST, JSON body with `key` and `text` (set `text` to the Message variable).
3. Turn off "Ask before running".

Test it from a terminal:

```
curl -X POST "YOUR_ENDPOINT" -H "Content-Type: application/json" \
  -d '{"key":"YOUR_KEY","text":"Rs.250.00 debited from A/c XX1234 to VPA swiggy@icici"}'
```

Treat the key like a password. Anyone who has it can add expenses to your account. Use "Make a new key" in the app if it leaks.

### 5. Install on your phone

Open the site in Chrome (Android) or Safari (iPhone), then choose Add to Home Screen. On Android, once installed, you can also select a bank message, tap Share, and pick Kharcha. It opens with the message already read.

## Tests

```
node js/parser.test.mjs
```

Runs the message reader against sample bank, card and UPI messages, including OTPs and credits that must be ignored. Real bank wording varies, so add your own messages to the list if something is misread.

## Customise

- Categories and colours: the `CATS` list at the top of `js/app.js` and the keyword rules at the top of `js/parser.js`
- Theme: CSS variables at the top of `css/style.css`

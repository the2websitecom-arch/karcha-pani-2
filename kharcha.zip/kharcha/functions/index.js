// Receives a payment message from a phone automation app and adds it as an expense.
//
// POST  { "key": "<your private key from the app>", "text": "<SMS or notification text>" }
//
// The key identifies you. It is created in the app under "Automatic capture".

import { onRequest } from 'firebase-functions/v2/https';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { createHash } from 'node:crypto';
import { parseSms } from './parser.js';

initializeApp();
const db = getFirestore();

// Today's date in India, whatever time zone the server runs in.
function todayIST() {
  return new Date(Date.now() + 5.5 * 3600 * 1000).toISOString().slice(0, 10);
}

export const ingest = onRequest(
  { region: 'asia-south1', maxInstances: 5, cors: false },
  async (req, res) => {
    if (req.method !== 'POST') {
      res.status(405).json({ error: 'Use POST.' });
      return;
    }

    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const key = String(body.key || '').trim();
    const text = String(body.text || '').trim();
    if (!/^[a-f0-9]{32}$/.test(key) || !text || text.length > 1000) {
      res.status(400).json({ error: 'Send JSON with a key and the message text.' });
      return;
    }

    const keyDoc = await db.doc('ingestTokens/' + key).get();
    if (!keyDoc.exists) {
      res.status(401).json({ error: 'Unknown key.' });
      return;
    }
    const uid = keyDoc.data().uid;

    const parsed = parseSms(text, todayIST());
    if (!parsed.ok) {
      // 200 so the phone automation does not retry messages that are not payments (OTPs, credits).
      res.status(200).json({ added: false, reason: parsed.reason });
      return;
    }

    // The same message sent twice (retries, SMS plus notification) is stored once.
    const id = 'sms_' + createHash('sha1').update(uid + '|' + text).digest('hex').slice(0, 20);
    try {
      await db.doc('users/' + uid + '/expenses/' + id).create({
        amt: parsed.amount,
        desc: parsed.desc,
        cat: parsed.category,
        date: parsed.date,
        source: 'sms',
        createdAt: FieldValue.serverTimestamp()
      });
    } catch (e) {
      if (e && (e.code === 6 || e.code === 'already-exists')) {
        res.status(200).json({ added: false, reason: 'Already added.' });
        return;
      }
      throw e;
    }
    res.status(200).json({ added: true, amount: parsed.amount, desc: parsed.desc, category: parsed.category });
  }
);

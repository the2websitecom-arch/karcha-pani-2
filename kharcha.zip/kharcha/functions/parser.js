// Reads Indian bank, card and UPI payment messages and returns an expense.
// Used by the app (paste an SMS) and by the cloud function (automatic capture).
// Keep js/parser.js and functions/parser.js identical.

const CATEGORY_RULES = [
  ['Food', /swiggy|zomato|restaurant|cafe|café|biryani|domino|pizza|kfc|mcdonald|starbucks|chai|bakery|eatery|dining|\bfood/i],
  ['Groceries', /bigbasket|blinkit|zepto|dmart|d-mart|instamart|grocer|kirana|supermarket|reliance fresh|more retail|vegetable|fruit|\bmilk/i],
  ['Transport', /\buber|\bola\b|olacabs|rapido|metro|irctc|redbus|petrol|fuel|hpcl|bpcl|iocl|indian oil|fastag|parking|\bcab\b/i],
  ['Bills', /airtel|\bjio|vodafone|\bvi\b|bsnl|electric|tsspdcl|bescom|tneb|water board|broadband|fibre|fiber|recharge|postpaid|\bdth\b|tata ?play|\bgas\b|insurance|\bemi\b|\bloan/i],
  ['Entertainment', /netflix|spotify|hotstar|prime video|bookmyshow|\bpvr|\binox|youtube|steam|movie|cinema/i],
  ['Health', /pharm|apollo|medplus|1mg|netmeds|hospital|clinic|diagnostic|\blab\b|doctor|\bgym\b|cult\.?fit/i],
  ['Shopping', /amazon|flipkart|myntra|ajio|nykaa|meesho|decathlon|zara|lifestyle|shoppers stop|croma|reliance digital/i],
  ['Rent', /\brent\b|nobroker|landlord/i]
];

const DEBIT = /\b(debited|debit|spent|sent|paid|payment of|purchase|purchased|withdrawn|withdrawal|txn of|transaction of|charged|deducted)\b/i;
const CREDIT = /\b(credited|received|refund(?:ed)?|reversed|cashback|deposited|salary)\b/i;
const SKIP = /\b(otp|one time password|verification code|failed|declined|unsuccessful|requested? money|due on|will be debited|mandate)\b|received (?:towards|in)|thank you for (?:your )?payment/i;
const AMOUNT_PREFIXED = /(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)/i;
const AMOUNT_AFTER_VERB = /\b(?:debited|spent|paid|sent|withdrawn|charged)\s+(?:by|for|of|with)\s+([\d,]+(?:\.\d{1,2})?)/i;
const BALANCE = /\b(?:avl|avail(?:able)?|total|current)?\s*(?:bal(?:ance)?|limit)\b[^.]{0,30}?(?:rs\.?|inr|₹)?\s*[\d,]+(?:\.\d{1,2})?/gi;
const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };

function pad(n) { return (n < 10 ? '0' : '') + n; }

function validDate(y, m, d) {
  if (y < 100) y += 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31 || y < 2000) return null;
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCMonth() !== m - 1) return null;
  return y + '-' + pad(m) + '-' + pad(d);
}

function findDate(text, todayISO) {
  let found = null;
  let m = text.match(/\b(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{2,4})\b/);
  if (m) found = validDate(+m[3], +m[2], +m[1]);
  if (!found) {
    m = text.match(/\b(\d{1,2})[-\/ ]?([A-Za-z]{3})[a-z]*[-\/ ,]*(\d{2,4})\b/);
    if (m && MONTHS[m[2].toLowerCase()]) found = validDate(+m[3], MONTHS[m[2].toLowerCase()], +m[1]);
  }
  // A date in the future means the message was misread; use today instead.
  return found && found <= todayISO ? found : todayISO;
}

function titleCase(s) {
  return s.toLowerCase().replace(/(^|[\s&'-])([a-z])/g, (_, a, b) => a + b.toUpperCase());
}

function tidyMerchant(raw) {
  let s = raw.trim().replace(/\s+/g, ' ');
  if (s.includes('@')) s = s.split('@')[0];
  s = s.replace(/[._-]+/g, ' ').replace(/\b\d{6,}\b/g, '').replace(/\s+/g, ' ').trim();
  if (!s || /^(your|a\/c|ac|account|xx|x{2,}|vpa|upi|bank|card|self)\b/i.test(s)) return null;
  return titleCase(s.slice(0, 40));
}

function findMerchant(text) {
  const stop = '(?=\\s+(?:on|via|using|ref|refno|upi|from|at|for|txn|dated|info|avl|bal)\\b|\\s*\\(|[.,;]|\\s*$)';
  const patterns = [
    new RegExp('\\bat\\s+([A-Za-z0-9@._&\'\\- ]{2,40}?)' + stop, 'i'),
    new RegExp('\\b(?:to|towards|trf to|transfer to)\\s+(?:vpa\\s+)?([A-Za-z0-9@._&\'\\- ]{2,40}?)' + stop, 'i')
  ];
  for (const re of patterns) {
    const m = text.match(re);
    if (m) {
      const name = tidyMerchant(m[1]);
      if (name) return name;
    }
  }
  return null;
}

function guessCategory(text) {
  for (const [cat, re] of CATEGORY_RULES) if (re.test(text)) return cat;
  return 'Shopping';
}

// parseSms(text, 'YYYY-MM-DD') -> { ok: true, amount, desc, category, date } or { ok: false, reason }
export function parseSms(input, todayISO) {
  const text = String(input || '').replace(/\s+/g, ' ').trim();
  if (!text) return { ok: false, reason: 'The message is empty.' };
  if (SKIP.test(text)) return { ok: false, reason: 'This looks like an OTP, a failed payment, or a reminder, not a completed payment.' };

  const d = text.search(DEBIT);
  const c = text.search(CREDIT);
  if (d === -1 && c !== -1) return { ok: false, reason: 'This looks like money received, so it was not added as an expense.' };
  if (d === -1) return { ok: false, reason: 'No payment found in this message.' };
  if (c !== -1 && c < d) return { ok: false, reason: 'This looks like money received, so it was not added as an expense.' };

  const body = text.replace(BALANCE, ' ');
  const am = body.match(AMOUNT_PREFIXED) || body.match(AMOUNT_AFTER_VERB);
  if (!am) return { ok: false, reason: 'Could not find an amount in this message.' };
  const amount = parseFloat(am[1].replace(/,/g, ''));
  if (!(amount > 0) || amount >= 10000000) return { ok: false, reason: 'The amount looks wrong.' };

  const merchant = findMerchant(body);
  return {
    ok: true,
    amount: Math.round(amount * 100) / 100,
    desc: merchant || 'Bank payment',
    category: guessCategory(merchant ? merchant + ' ' + body : body),
    date: findDate(body, todayISO)
  };
}

import { createStore } from './store.js';
import { parseSms } from './parser.js';
import { ingestUrl, hasIngestUrl } from './firebase-config.js';

const CATS = [
  { id: 'Food', color: '#E8743B' },
  { id: 'Groceries', color: '#3FA34D' },
  { id: 'Rent', color: '#3B6FD4' },
  { id: 'Transport', color: '#8A5CD0' },
  { id: 'Bills', color: '#D4A017' },
  { id: 'Entertainment', color: '#D44A8A' },
  { id: 'Health', color: '#17A2B8' },
  { id: 'Shopping', color: '#7A8B99' }
];
const CAT = {};
CATS.forEach((c) => { CAT[c.id] = c; });
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const $ = (id) => document.getElementById(id);
const inr = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });
const inr2 = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 });
const money = (n) => (Math.round(n) === n ? inr : inr2).format(n);
const short = (n) => (n >= 100000 ? (n / 100000).toFixed(1).replace('.0', '') + 'L' : n >= 1000 ? (n / 1000).toFixed(n % 1000 ? 1 : 0).replace('.0', '') + 'k' : String(Math.round(n)));
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = (n) => (n < 10 ? '0' : '') + n;
const isoOf = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const ymOf = (s) => +s.slice(0, 4) * 12 + (+s.slice(5, 7) - 1);

const now = new Date();
const todayISO = isoOf(now);
const thisYM = now.getFullYear() * 12 + now.getMonth();

let store = null;
let S = { expenses: [], budget: 50000, ingestToken: null };
let viewYM = thisYM;
let selCat = 'Food';
let lastDeleted = null;
let toastTimer = null;
let unsubscribe = null;
let budgetTimer = null;

// ------------------------------------------------------------------ start

async function start() {
  try {
    store = await createStore();
  } catch (e) {
    $('boot').textContent = 'Could not load Firebase. Check your internet connection and refresh.';
    return;
  }
  setupStaticUI();
  store.onAuth((user) => {
    $('boot').hidden = true;
    if (unsubscribe) { unsubscribe(); unsubscribe = null; }
    if (!user) { showAuth(); return; }
    showApp(user);
  });
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  }
}

function showAuth() {
  $('appScreen').hidden = true;
  $('authScreen').hidden = false;
  S = { expenses: [], budget: 50000, ingestToken: null };
}

function showApp(user) {
  $('authScreen').hidden = true;
  $('appScreen').hidden = false;
  const local = store.mode === 'local';
  $('demoBanner').hidden = !local;
  $('signout').hidden = local;
  $('whoami').textContent = local ? '' : user.name || '';
  $('autoCloud').hidden = local;
  $('autoLocal').hidden = !local;
  $('ingestUrl').value = hasIngestUrl ? ingestUrl : '';
  $('urlWarn').hidden = hasIngestUrl;
  unsubscribe = store.subscribe((data) => {
    S = data;
    if (data.ingestToken) $('ingestKey').value = data.ingestToken;
    render();
  });
  handleSharedText();
}

// ------------------------------------------------------------------ auth screen

let authMode = 'login';
function setAuthMode(mode) {
  authMode = mode;
  $('tabLogin').setAttribute('aria-selected', String(mode === 'login'));
  $('tabSignup').setAttribute('aria-selected', String(mode === 'signup'));
  $('nameField').hidden = mode !== 'signup';
  $('authSubmit').textContent = mode === 'signup' ? 'Create account' : 'Log in';
  $('authPass').autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
  $('forgot').hidden = mode === 'signup';
  $('authErr').textContent = '';
  $('authMsg').textContent = '';
}

function friendlyAuthError(e) {
  const code = (e && e.code) || '';
  const map = {
    'auth/invalid-credential': 'Email or password is incorrect.',
    'auth/wrong-password': 'Email or password is incorrect.',
    'auth/user-not-found': 'Email or password is incorrect.',
    'auth/email-already-in-use': 'An account with this email already exists. Try logging in.',
    'auth/weak-password': 'Use a password with at least 6 characters.',
    'auth/invalid-email': 'Enter a valid email address.',
    'auth/missing-password': 'Enter your password.',
    'auth/too-many-requests': 'Too many attempts. Wait a few minutes and try again.',
    'auth/network-request-failed': 'No connection. Check your internet and try again.',
    'auth/popup-closed-by-user': '',
    'auth/cancelled-popup-request': '',
    'auth/unauthorized-domain': 'This website address is not allowed in Firebase yet. Add it under Authentication, Settings, Authorized domains.',
    'auth/operation-not-allowed': 'This sign-in method is not turned on in Firebase yet. Enable it under Authentication, Sign-in method.'
  };
  return code in map ? map[code] : 'Something went wrong. Try again.';
}

async function runAuth(fn) {
  $('authErr').textContent = '';
  $('authMsg').textContent = '';
  $('authSubmit').disabled = true;
  try { await fn(); } catch (e) { $('authErr').textContent = friendlyAuthError(e); }
  $('authSubmit').disabled = false;
}

// ------------------------------------------------------------------ one-time UI wiring

function setupStaticUI() {
  // auth
  $('tabLogin').addEventListener('click', () => setAuthMode('login'));
  $('tabSignup').addEventListener('click', () => setAuthMode('signup'));
  $('authForm').addEventListener('submit', (ev) => {
    ev.preventDefault();
    const email = $('authEmail').value.trim(), pw = $('authPass').value;
    if (!email) { $('authErr').textContent = 'Enter your email.'; return; }
    if (!pw) { $('authErr').textContent = 'Enter your password.'; return; }
    runAuth(() => (authMode === 'signup' ? store.signUp($('authName').value.trim(), email, pw) : store.signIn(email, pw)));
  });
  $('forgot').addEventListener('click', () => {
    const email = $('authEmail').value.trim();
    if (!email) { $('authErr').textContent = 'Type your email above, then tap this again.'; return; }
    runAuth(async () => { await store.reset(email); $('authMsg').textContent = 'If an account exists for ' + email + ', a reset link is on its way.'; });
  });
  $('googleBtn').addEventListener('click', () => runAuth(() => store.google()));
  $('signout').addEventListener('click', () => store.signOut());

  // header
  $('prev').addEventListener('click', () => { viewYM--; render(); });
  $('next').addEventListener('click', () => { if (viewYM < thisYM) { viewYM++; render(); } });
  $('theme').addEventListener('click', () => {
    const root = document.documentElement;
    const cur = root.getAttribute('data-theme');
    const dark = cur === 'dark' || (!cur && matchMedia('(prefers-color-scheme: dark)').matches);
    root.setAttribute('data-theme', dark ? 'light' : 'dark');
  });
  $('clearSample').addEventListener('click', () => store.clearSamples());

  // budget (saved shortly after you stop typing)
  $('budget').addEventListener('input', () => {
    S.budget = Math.max(0, +$('budget').value || 0);
    render();
    clearTimeout(budgetTimer);
    budgetTimer = setTimeout(() => store.setBudget(Math.max(0, +$('budget').value || 0)), 600);
  });

  // add form
  const optionHtml = CATS.map((c) => '<option>' + c.id + '</option>').join('');
  $('filterCat').innerHTML = '<option value="">All categories</option>' + optionHtml;
  $('prCat').innerHTML = optionHtml;
  $('date').value = todayISO;
  $('date').max = todayISO;
  renderCatPicker();
  $('cats').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    selCat = b.getAttribute('data-cat');
    renderCatPicker();
  });
  $('form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const amt = parseFloat($('amount').value), desc = $('desc').value.trim(), date = $('date').value;
    if (!(amt > 0)) { $('err').textContent = 'Enter an amount greater than zero.'; $('amount').focus(); return; }
    if (!desc) { $('err').textContent = 'Add a short description.'; $('desc').focus(); return; }
    if (!date) { $('err').textContent = 'Pick a date.'; $('date').focus(); return; }
    $('err').textContent = '';
    const entry = { amt: Math.round(amt * 100) / 100, desc, cat: selCat, date };
    viewYM = ymOf(date);
    $('amount').value = '';
    $('desc').value = '';
    $('amount').focus();
    await saveExpense(entry);
  });

  // list actions
  $('search').addEventListener('input', renderLedgerOnly);
  $('filterCat').addEventListener('change', renderLedgerOnly);
  $('ledger').addEventListener('click', async (e) => {
    const b = e.target.closest('button[data-id]');
    if (!b) return;
    const item = S.expenses.find((x) => x.id === b.getAttribute('data-id'));
    if (!item) return;
    lastDeleted = item;
    try { await store.remove(item.id); showToast('Deleted ' + item.desc, true); }
    catch (err) { showToast('Could not delete. Check your connection.', false); }
  });
  $('undo').addEventListener('click', async () => {
    if (lastDeleted) { try { await store.restore(lastDeleted); } catch (e) { /* ignore */ } lastDeleted = null; }
    $('toast').hidden = true;
  });

  // payment message
  $('smsRead').addEventListener('click', readSms);
  $('prCancel').addEventListener('click', () => { $('smsPreview').hidden = true; $('smsErr').textContent = ''; });
  $('prAdd').addEventListener('click', async () => {
    const amt = parseFloat($('prAmt').value), desc = $('prDesc').value.trim(), date = $('prDate').value;
    if (!(amt > 0) || !desc || !date) { $('smsErr').textContent = 'Check the amount, description and date.'; return; }
    $('smsErr').textContent = '';
    viewYM = ymOf(date);
    await saveExpense({ amt: Math.round(amt * 100) / 100, desc, cat: $('prCat').value, date, source: 'sms' });
    $('sms').value = '';
    $('smsPreview').hidden = true;
  });

  // automatic capture
  $('auto').addEventListener('toggle', async () => {
    if (!$('auto').open || store.mode !== 'cloud' || $('ingestKey').value) return;
    try { $('ingestKey').value = await store.ensureIngestToken(); }
    catch (e) { $('ingestKey').placeholder = 'Could not create a key. Check your connection.'; }
  });
  $('rotateKey').addEventListener('click', async () => {
    $('ingestKey').value = '';
    try { $('ingestKey').value = await store.rotateIngestToken(); showToast('New key created. Update your phone automation.', false); }
    catch (e) { showToast('Could not create a new key.', false); }
  });
  document.querySelectorAll('[data-copy]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const input = $(btn.getAttribute('data-copy'));
      if (!input.value) return;
      try { await navigator.clipboard.writeText(input.value); btn.textContent = 'Copied'; }
      catch (e) { input.select(); btn.textContent = 'Press copy'; }
      setTimeout(() => { btn.textContent = 'Copy'; }, 1500);
    });
  });
}

async function saveExpense(entry) {
  try {
    await store.add(entry);
    showToast('Added ' + money(entry.amt) + ' to ' + entry.cat, false);
  } catch (e) {
    showToast('Could not save. Check your connection and try again.', false);
  }
}

function showToast(msg, canUndo) {
  $('toastMsg').textContent = msg;
  $('undo').hidden = !canUndo;
  $('toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { $('toast').hidden = true; }, 5000);
}

// ------------------------------------------------------------------ payment message

function readSms() {
  const res = parseSms($('sms').value, todayISO);
  if (!res.ok) { $('smsPreview').hidden = true; $('smsErr').textContent = res.reason; return; }
  $('smsErr').textContent = '';
  $('prAmt').value = res.amount;
  $('prDesc').value = res.desc;
  $('prCat').value = res.category;
  $('prDate').value = res.date;
  $('prDate').max = todayISO;
  $('smsPreview').hidden = false;
}

// Android share sheet: sharing a message to the installed app opens it with ?text=...
function handleSharedText() {
  const p = new URLSearchParams(location.search);
  const text = [p.get('title'), p.get('text'), p.get('url')].filter(Boolean).join(' ').trim();
  if (!text) return;
  history.replaceState(null, '', location.pathname);
  $('sms').value = text;
  readSms();
  $('sms').scrollIntoView({ block: 'center' });
}

// ------------------------------------------------------------------ render

function renderCatPicker() {
  $('cats').innerHTML = CATS.map((c) => '<button type="button" data-cat="' + c.id + '" aria-pressed="' + (c.id === selCat) + '"><i style="background:' + c.color + '"></i>' + c.id + '</button>').join('');
}

function monthItems() { return S.expenses.filter((e) => ymOf(e.date) === viewYM); }

function render() {
  const y = Math.floor(viewYM / 12), m = viewYM % 12;
  $('monthLabel').textContent = MONTHS[m] + ' ' + y;
  $('next').disabled = viewYM >= thisYM;
  const items = monthItems();
  const dim = new Date(y, m + 1, 0).getDate();
  const isCurrent = viewYM === thisYM;
  const elapsed = isCurrent ? now.getDate() : dim;
  const total = items.reduce((s, e) => s + e.amt, 0);
  const budget = Math.max(0, +S.budget || 0);

  $('spent').textContent = money(total);
  const ratio = budget ? total / budget : 0;
  const cls = ratio > 1 ? 'bad' : ratio > 0.85 ? 'warn' : 'ok';
  $('status').className = 'pill ' + cls;
  $('statusText').textContent = !budget ? 'No budget set' : ratio > 1 ? 'Over budget' : ratio > 0.85 ? 'Close to limit' : 'On track';
  $('meter').className = 'meter ' + cls;
  $('meter').setAttribute('aria-valuenow', Math.min(100, Math.round(ratio * 100)));
  $('meterFill').style.width = Math.min(100, ratio * 100) + '%';
  const left = budget - total;
  if (!budget) $('leftText').textContent = 'Set a monthly budget to track what is left.';
  else if (left < 0) $('leftText').textContent = money(-left) + ' over a budget of ' + money(budget);
  else if (isCurrent && dim - elapsed > 0) $('leftText').textContent = money(left) + ' left, about ' + money(Math.floor(left / (dim - elapsed))) + ' a day for ' + (dim - elapsed) + ' more days';
  else $('leftText').textContent = money(left) + ' left of ' + money(budget);
  if (document.activeElement !== $('budget')) $('budget').value = budget || '';

  $('avg').textContent = money(total / Math.max(1, elapsed));
  const big = items.slice().sort((a, b) => b.amt - a.amt)[0];
  $('biggest').textContent = big ? money(big.amt) : '–';
  $('count').textContent = items.length;

  renderDonut(items, total);
  renderBars(items, m, dim);
  renderLedger(items);
  $('clearSample').hidden = !(store && store.hasSamples());
}

function renderDonut(items, total) {
  const by = {};
  items.forEach((e) => { by[e.cat] = (by[e.cat] || 0) + e.amt; });
  const rows = CATS.filter((c) => by[c.id]).map((c) => ({ c, v: by[c.id] })).sort((a, b) => b.v - a.v);
  if (!rows.length) { $('donutRow').innerHTML = '<div class="empty" style="width:100%">No expenses this month yet.</div>'; return; }
  let acc = 0, circles = '';
  rows.forEach((r) => {
    const pct = (r.v / total) * 100;
    const vis = Math.max(0.2, pct - (rows.length > 1 ? 0.8 : 0));
    circles += '<circle cx="60" cy="60" r="48" fill="none" stroke="' + r.c.color + '" stroke-width="16" pathLength="100" stroke-dasharray="' + vis.toFixed(2) + ' ' + (100 - vis).toFixed(2) + '" stroke-dashoffset="' + (-acc).toFixed(2) + '"/>';
    acc += pct;
  });
  const legend = rows.map((r) => '<li><i style="background:' + r.c.color + '"></i><span>' + r.c.id + '</span><span class="pct">' + Math.round((r.v / total) * 100) + '%</span><span class="amt">' + money(r.v) + '</span></li>').join('');
  $('donutRow').innerHTML =
    '<div class="donut" role="img" aria-label="Spending by category"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="48" fill="none" stroke="var(--soft)" stroke-width="16"/>' + circles + '</svg>' +
    '<div class="mid"><span class="label">Top</span><b>' + rows[0].c.id + '</b></div></div><ul class="legend">' + legend + '</ul>';
}

function renderBars(items, m, dim) {
  const days = new Array(dim).fill(0);
  items.forEach((e) => { days[+e.date.slice(8, 10) - 1] += e.amt; });
  const max = Math.max(...days);
  if (!max) { $('barsWrap').innerHTML = '<div class="empty">Nothing to chart yet.</div>'; return; }
  const step = max > 20000 ? 10000 : max > 8000 ? 5000 : max > 4000 ? 2000 : max > 1500 ? 1000 : 500;
  const top = Math.ceil(max / step) * step;
  const W = 640, H = 190, L = 40, R = 6, T = 8, B = 24;
  const pw = W - L - R, ph = H - T - B, slot = pw / dim, bw = Math.max(3, slot * 0.66);
  let svg = '<svg class="bars" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Spending per day">';
  for (let v = 0; v <= top; v += step) {
    const yy = T + ph - (v / top) * ph;
    svg += '<line class="grid-l" x1="' + L + '" x2="' + (W - R) + '" y1="' + yy + '" y2="' + yy + '"/><text x="' + (L - 6) + '" y="' + (yy + 4) + '" text-anchor="end">' + short(v) + '</text>';
  }
  days.forEach((d, i) => {
    if (!d) return;
    const h = (d / top) * ph, x = L + i * slot + (slot - bw) / 2;
    svg += '<rect class="b' + (d === max ? ' hi' : '') + '" x="' + x.toFixed(1) + '" y="' + (T + ph - h).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + h.toFixed(1) + '" rx="2"><title>' + (i + 1) + ' ' + MONTHS[m].slice(0, 3) + ': ' + money(d) + '</title></rect>';
  });
  [1, 8, 15, 22, dim].forEach((d) => {
    svg += '<text x="' + (L + (d - 1) * slot + slot / 2).toFixed(1) + '" y="' + (H - 6) + '" text-anchor="middle">' + d + '</text>';
  });
  $('barsWrap').innerHTML = svg + '</svg>';
}

function renderLedgerOnly() { renderLedger(monthItems()); }

function renderLedger(items) {
  const q = $('search').value.trim().toLowerCase(), fc = $('filterCat').value;
  const list = items
    .filter((e) => (!fc || e.cat === fc) && (!q || e.desc.toLowerCase().indexOf(q) > -1))
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
  if (!list.length) {
    $('ledger').innerHTML = '<li class="empty">' + (items.length ? 'No expenses match this filter.' : 'No expenses this month. Add one from the form, or set up automatic capture.') + '</li>';
    return;
  }
  const dayTotals = {};
  list.forEach((e) => { dayTotals[e.date] = (dayTotals[e.date] || 0) + e.amt; });
  let html = '', cur = '';
  list.forEach((e) => {
    if (e.date !== cur) {
      cur = e.date;
      const d = new Date(e.date + 'T00:00:00');
      const name = e.date === todayISO ? 'Today' : d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
      html += '<li class="day"><span>' + name + '</span><span class="num">' + money(dayTotals[e.date]) + '</span></li>';
    }
    const color = (CAT[e.cat] || CAT.Shopping).color;
    html += '<li class="row"><i style="background:' + color + '"></i><span class="d">' + esc(e.desc) + '<span class="c">' + esc(e.cat) + (e.source === 'sms' ? '<span class="tag">SMS</span>' : '') + '</span></span><span class="a">' + money(e.amt) + '</span>' +
      '<button data-id="' + esc(e.id) + '" aria-label="Delete ' + esc(e.desc) + '"><svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.6 8h5.8l.6-8"/></svg></button></li>';
  });
  $('ledger').innerHTML = html;
}

start();

// Paste your Firebase web app config here.
// Firebase console > Project settings > General > Your apps > Web app > SDK setup and configuration.
// These values are safe to publish. Access is controlled by firestore.rules, not by hiding the keys.
//
// Until you replace the placeholders, Kharcha runs in demo mode: no sign-in, data stays in this browser.

export const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};

// After you deploy the cloud function (see README), paste its URL here.
// It looks like https://ingest-xxxxxxxx-el.a.run.app
export const ingestUrl = "PASTE_INGEST_FUNCTION_URL";

export const isConfigured = !String(firebaseConfig.apiKey).startsWith("PASTE");
export const hasIngestUrl = !String(ingestUrl).startsWith("PASTE");

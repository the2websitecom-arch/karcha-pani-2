// Run with: node js/parser.test.mjs
import { parseSms } from './parser.js';

const TODAY = '2026-10-14';
const cases = [
  ['Rs.250.00 debited from A/c XX1234 on 14-10-26 to VPA swiggy@icici. UPI Ref 123456789012. Avl Bal Rs 10,000.00', { amount: 250, desc: 'Swiggy', category: 'Food', date: '2026-10-14' }],
  ['Sent Rs.120.00 From HDFC Bank A/C *1234 To BigBasket On 13/10/26 Ref 123456', { amount: 120, desc: 'Bigbasket', category: 'Groceries', date: '2026-10-13' }],
  ['INR 1,250.00 spent on HDFC Bank Card XX1234 at AMAZON on 12-Oct-26. Avl Limit INR 50,000', { amount: 1250, desc: 'Amazon', category: 'Shopping', date: '2026-10-12' }],
  ['Dear UPI user A/C X1234 debited by 500.0 on date 11Oct26 trf to Rapido Refno 998877', { amount: 500, desc: 'Rapido', category: 'Transport', date: '2026-10-11' }],
  ['Paid ₹399 to Airtel Postpaid via UPI', { amount: 399, desc: 'Airtel Postpaid', category: 'Bills' }],
  ['Rs 18000 debited from a/c XX1234 on 01-10-2026 to VPA landlord@okaxis rent', { amount: 18000, category: 'Rent', date: '2026-10-01' }],
  ['Rs.5000.00 credited to A/c XX1234 on 14-10-26 by UPI from friend@ybl', null],
  ['Your OTP for transaction of Rs.250 is 123456. Do not share.', null],
  ['Payment of Rs. 5,000 received towards your credit card ending 1234. Thank you.', null],
  ['Rs.250 debited for UPI mandate. Transaction failed.', null],
  ['Hello, how are you?', null]
];

let failed = 0;
for (const [text, want] of cases) {
  const got = parseSms(text, TODAY);
  let ok;
  if (want === null) ok = !got.ok;
  else ok = got.ok && Object.entries(want).every(([k, v]) => got[k] === v);
  if (!ok) failed++;
  console.log((ok ? 'PASS' : 'FAIL') + '  ' + text.slice(0, 70));
  if (!ok) console.log('      got:', JSON.stringify(got), 'want:', JSON.stringify(want));
}
console.log(failed ? failed + ' failed' : 'all passed');
process.exit(failed ? 1 : 0);

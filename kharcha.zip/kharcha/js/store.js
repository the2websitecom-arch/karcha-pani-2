// Data layer. Two interchangeable stores with the same methods:
//   cloud store: Firebase Auth + Firestore (used once firebase-config.js is filled in)
//   local store: browser localStorage with example entries (demo mode)

import { firebaseConfig, isConfigured } from './firebase-config.js';

const FIREBASE_VERSION = '10.14.1';
const DEFAULT_BUDGET = 50000;

function randomHex(bytes) {
  const a = new Uint8Array(bytes);
  crypto.getRandomValues(a);
  return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
}
function newId() { return 'e' + randomHex(9); }
function pad(n) { return (n < 10 ? '0' : '') + n; }

// ---------------------------------------------------------------- local (demo)

const LOCAL_KEY = 'kharcha-v1';
const SEED = [
  [1, 'Rent, Madhapur flat', 'Rent', 18000], [2, 'BigBasket weekly order', 'Groceries', 2340], [2, 'Biryani at Paradise', 'Food', 640],
  [3, 'Electricity bill', 'Bills', 1240], [3, 'Metro card top-up', 'Transport', 500], [4, 'Airtel fibre', 'Bills', 899],
  [5, 'Chai and snacks', 'Food', 180], [6, 'Movie at PVR', 'Entertainment', 720], [8, 'Vegetables, Rythu Bazaar', 'Groceries', 460],
  [9, 'Rapido to office', 'Transport', 210], [10, 'Running shoes', 'Shopping', 3499], [11, 'Zomato dinner', 'Food', 520],
  [12, 'Pharmacy', 'Health', 385], [13, 'Lunch with team', 'Food', 850], [14, 'Petrol', 'Transport', 1200],
  [16, 'Groceries, DMart', 'Groceries', 1980], [17, 'Filter coffee', 'Food', 160], [19, 'Dosa breakfast', 'Food', 140],
  [20, 'Fruits and milk', 'Groceries', 620], [21, 'Spotify', 'Entertainment', 119], [22, 'Dinner out', 'Food', 1450],
  [24, 'Gym membership', 'Health', 1500], [25, 'Cab to airport', 'Transport', 780], [26, 'Kurta', 'Shopping', 1299],
  [27, 'Mobile recharge', 'Bills', 349], [28, 'Groceries, BigBasket', 'Groceries', 2100]
];

function makeSeed() {
  const now = new Date();
  const factor = [1, 0.92, 1.08];
  const out = [];
  for (let m = 0; m < 3; m++) {
    const base = new Date(now.getFullYear(), now.getMonth() - m, 1);
    const dim = new Date(base.getFullYear(), base.getMonth() + 1, 0).getDate();
    SEED.forEach((s, i) => {
      if (s[0] > dim || (m === 0 && s[0] > now.getDate())) return;
      const fixed = s[2] === 'Rent' || s[1] === 'Spotify';
      out.push({
        id: 'sample' + m + '_' + i,
        amt: fixed ? s[3] : Math.round((s[3] * factor[m]) / 10) * 10,
        desc: s[1], cat: s[2],
        date: base.getFullYear() + '-' + pad(base.getMonth() + 1) + '-' + pad(s[0]),
        sample: true
      });
    });
  }
  return out;
}

function createLocalStore() {
  let state = { expenses: [], budget: DEFAULT_BUDGET, seeded: false };
  try {
    const saved = JSON.parse(localStorage.getItem(LOCAL_KEY) || 'null');
    if (saved && Array.isArray(saved.expenses)) state = Object.assign(state, saved);
  } catch (e) { /* private window or blocked storage */ }
  if (!state.seeded) { state.expenses = state.expenses.concat(makeSeed()); state.seeded = true; }

  const listeners = new Set();
  const emit = () => {
    try { localStorage.setItem(LOCAL_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
    listeners.forEach((cb) => cb({ expenses: state.expenses.slice(), budget: state.budget, ingestToken: null }));
  };

  return {
    mode: 'local',
    onAuth(cb) { cb({ local: true, name: 'Demo' }); return () => {}; },
    subscribe(cb) { listeners.add(cb); emit(); return () => listeners.delete(cb); },
    async add(e) { state.expenses.push(Object.assign({ id: newId() }, e)); emit(); },
    async remove(id) { state.expenses = state.expenses.filter((x) => x.id !== id); emit(); },
    async restore(e) { state.expenses.push(e); emit(); },
    async setBudget(n) { state.budget = n; emit(); },
    async clearSamples() { state.expenses = state.expenses.filter((x) => !x.sample); emit(); },
    hasSamples() { return state.expenses.some((x) => x.sample); },
    async ensureIngestToken() { return null; },
    async rotateIngestToken() { return null; },
    async signIn() {}, async signUp() {}, async google() {}, async reset() {}, async signOut() {}
  };
}

// ---------------------------------------------------------------- cloud (Firebase)

async function createCloudStore() {
  const base = 'https://www.gstatic.com/firebasejs/' + FIREBASE_VERSION + '/';
  const [appMod, A, F] = await Promise.all([
    import(base + 'firebase-app.js'),
    import(base + 'firebase-auth.js'),
    import(base + 'firebase-firestore.js')
  ]);
  const app = appMod.initializeApp(firebaseConfig);
  const auth = A.getAuth(app);
  const db = F.initializeFirestore(app, {
    localCache: F.persistentLocalCache({ tabManager: F.persistentMultipleTabManager() })
  });

  const uid = () => auth.currentUser.uid;
  const userDoc = () => F.doc(db, 'users', uid());
  const expDoc = (id) => F.doc(db, 'users', uid(), 'expenses', id);
  let latestToken = null;

  function clean(e) {
    const out = { amt: e.amt, desc: e.desc, cat: e.cat, date: e.date };
    if (e.source) out.source = e.source;
    return out;
  }

  return {
    mode: 'cloud',
    onAuth(cb) {
      return A.onAuthStateChanged(auth, (u) => cb(u ? { uid: u.uid, name: u.displayName || u.email, email: u.email } : null));
    },
    subscribe(cb) {
      const state = { expenses: [], budget: DEFAULT_BUDGET, ingestToken: null };
      const push = () => cb({ expenses: state.expenses.slice(), budget: state.budget, ingestToken: state.ingestToken });
      const u1 = F.onSnapshot(F.collection(db, 'users', uid(), 'expenses'), (snap) => {
        state.expenses = snap.docs.map((d) => Object.assign({ id: d.id }, d.data()));
        push();
      });
      const u2 = F.onSnapshot(userDoc(), (snap) => {
        const d = snap.data() || {};
        if (typeof d.budget === 'number') state.budget = d.budget;
        state.ingestToken = d.ingestToken || null;
        latestToken = state.ingestToken;
        push();
      });
      return () => { u1(); u2(); };
    },
    async add(e) { await F.setDoc(expDoc(newId()), Object.assign(clean(e), { createdAt: F.serverTimestamp() })); },
    async remove(id) { await F.deleteDoc(expDoc(id)); },
    async restore(e) { await F.setDoc(expDoc(e.id), Object.assign(clean(e), { createdAt: F.serverTimestamp() })); },
    async setBudget(n) { await F.setDoc(userDoc(), { budget: n }, { merge: true }); },
    async clearSamples() {},
    hasSamples() { return false; },
    async ensureIngestToken() {
      if (latestToken) return latestToken;
      const snap = await F.getDoc(userDoc());
      const existing = snap.exists() && snap.data().ingestToken;
      if (existing) { latestToken = existing; return existing; }
      return this.rotateIngestToken();
    },
    async rotateIngestToken() {
      const old = latestToken;
      const token = randomHex(16);
      await F.setDoc(F.doc(db, 'ingestTokens', token), { uid: uid() });
      await F.setDoc(userDoc(), { ingestToken: token }, { merge: true });
      if (old) { try { await F.deleteDoc(F.doc(db, 'ingestTokens', old)); } catch (e) { /* old key already gone */ } }
      latestToken = token;
      return token;
    },
    signIn(email, pw) { return A.signInWithEmailAndPassword(auth, email, pw); },
    async signUp(name, email, pw) {
      const cred = await A.createUserWithEmailAndPassword(auth, email, pw);
      if (name) await A.updateProfile(cred.user, { displayName: name });
      return cred;
    },
    async google() {
      const provider = new A.GoogleAuthProvider();
      try { return await A.signInWithPopup(auth, provider); }
      catch (e) {
        if (e && e.code === 'auth/popup-blocked') return A.signInWithRedirect(auth, provider);
        throw e;
      }
    },
    reset(email) { return A.sendPasswordResetEmail(auth, email); },
    signOut() { return A.signOut(auth); }
  };
}

export async function createStore() {
  return isConfigured ? createCloudStore() : createLocalStore();
}

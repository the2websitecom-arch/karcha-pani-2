// Minimal service worker so the app can be installed on a phone home screen.
// It does not cache anything, so you always get the latest version.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
